Before running the Assignment 1 Code of Aidan Lockwood (student number: 10515402), please run the following comand:

pip install -r requirements.txt 

in the directory of the assignment folder.
The following code has been tested for python versions up to 3.13.

Once ready, run the code and all should work.

Thank you,
Aidan Lockwood